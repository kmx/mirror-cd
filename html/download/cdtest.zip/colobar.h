#ifndef COLORBAR_H
#define COLORBAR_H

int ColorBarInit(Ihandle *parent, Ihandle *canvas, long int *fc, long int *bc);
void ColorBarClose(void);

#endif
